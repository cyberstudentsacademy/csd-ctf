import base64

def xor_and_base64_encode(input_bytes):
    xored_bytes = bytes([byte ^ 4 for byte in input_bytes])
    base64_encoded = base64.b64encode(xored_bytes)
    hex_encoded = base64_encoded.hex()
    return hex_encoded

if __name__ == "__main__":
    try:
        input_data = input("Enter data to encode: ")
        input_bytes = input_data.encode()
        encoded_data = xor_and_base64_encode(input_bytes)
        print("Encoded data :", encoded_data)
    except Exception as e:
        print("An error occurred:", str(e))
