def reverse_shift_encrypt(plaintext):
  reversed_text = plaintext[::-1]
  ciphertext = ''
  for i, char in enumerate(reversed_text):
      shift_amount = i
      shifted_char = chr((ord(char) - ord('a') + shift_amount) % 26 + ord('a')) if char.islower() else \
          chr((ord(char) - ord('A') + shift_amount) % 26 + ord('A')) if char.isupper() else char
      ciphertext += shifted_char
  return ciphertext

if __name__ == "__main__":
  plaintext = input("Enter the plaintext: ")
  encrypted_text = reverse_shift_encrypt(plaintext)
  print("Encrypted text:", encrypted_text)